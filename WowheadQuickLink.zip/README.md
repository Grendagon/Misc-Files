# Wowhead Quick Link
Mouse over and press CTRL-C on (almost) anything to generate a Wowhead or Armory link. Allows you to quickly look up anything on Wowhead without having to manually search for it. Lightweight and efficient.

Supports generating links to the Wowhead page for quests, achievements, items, spells, buffs, NPCs, mounts, battle pets, factions, or currencies by pressing CTRL-C while mousing over, as well as armory links for player characters. Also supports Raider.IO links by pressing CTRL-SHIFT-C.


Available as an AddOn here: https://www.curseforge.com/wow/addons/wowhead-quick-link
